"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function StressAnalysis() {
  const [text, setText] = useState("")
  const [result, setResult] = useState<{ score: number; sentiment: string } | null>(null)

  const analyzeStress = async () => {
    // In a real application, this would be an API call to your ML model
    const response = await fetch("/api/analyze-stress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    })
    const data = await response.json()
    setResult(data)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Stress Analysis</h1>
      <Card>
        <CardHeader>
          <CardTitle>How are you feeling today?</CardTitle>
          <CardDescription>
            Write a few sentences about your day or current feelings. Our AI will analyze your stress levels.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Type your thoughts here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={5}
            className="mb-4"
          />
          <Button onClick={analyzeStress} disabled={text.length < 10}>
            Analyze Stress Levels
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Analysis Result</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="font-semibold">Stress Level:</p>
                <Progress value={result.score} className="w-full" />
                <p className="text-sm text-muted-foreground mt-1">
                  Score: {result.score}/100 ({result.score < 30 ? "Low" : result.score < 70 ? "Moderate" : "High"}{" "}
                  stress)
                </p>
              </div>
              <div>
                <p className="font-semibold">Sentiment Analysis:</p>
                <p>{result.sentiment}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
