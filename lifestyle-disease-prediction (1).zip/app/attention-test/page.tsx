"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

const TOTAL_SYMBOLS = 20
const DISPLAY_TIME = 5000 // 5 seconds

export default function AttentionTest() {
  const [symbols, setSymbols] = useState<string[]>([])
  const [userInput, setUserInput] = useState<string[]>([])
  const [testState, setTestState] = useState<"ready" | "displaying" | "input" | "result">("ready")
  const [score, setScore] = useState(0)

  const generateSymbols = () => {
    const possibleSymbols = ["●", "■", "▲", "◆", "★", "○", "□", "△", "◇", "☆"]
    return Array.from(
      { length: TOTAL_SYMBOLS },
      () => possibleSymbols[Math.floor(Math.random() * possibleSymbols.length)],
    )
  }

  const startTest = () => {
    const newSymbols = generateSymbols()
    setSymbols(newSymbols)
    setTestState("displaying")
    setTimeout(() => {
      setTestState("input")
    }, DISPLAY_TIME)
  }

  const handleSymbolClick = (symbol: string) => {
    if (testState === "input") {
      setUserInput((prev) => [...prev, symbol])
    }
  }

  const submitTest = () => {
    const correctAnswers = symbols.filter((symbol, index) => symbol === userInput[index]).length
    setScore((correctAnswers / TOTAL_SYMBOLS) * 100)
    setTestState("result")
  }

  const resetTest = () => {
    setSymbols([])
    setUserInput([])
    setTestState("ready")
    setScore(0)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Attention Span Test</h1>
      <Card>
        <CardHeader>
          <CardTitle>Symbol Recall Test</CardTitle>
          <CardDescription>
            A series of symbols will be displayed. Try to remember and recreate the sequence.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {testState === "ready" && <Button onClick={startTest}>Start Test</Button>}
          {testState === "displaying" && (
            <div className="flex flex-wrap justify-center gap-2 text-4xl">
              {symbols.map((symbol, index) => (
                <span key={index}>{symbol}</span>
              ))}
            </div>
          )}
          {testState === "input" && (
            <div className="space-y-4">
              <div className="flex flex-wrap justify-center gap-2">
                {["●", "■", "▲", "◆", "★", "○", "□", "△", "◇", "☆"].map((symbol) => (
                  <Button key={symbol} onClick={() => handleSymbolClick(symbol)} variant="outline">
                    {symbol}
                  </Button>
                ))}
              </div>
              <div className="flex flex-wrap justify-center gap-2 text-2xl">
                {userInput.map((symbol, index) => (
                  <span key={index}>{symbol}</span>
                ))}
              </div>
              <Button onClick={submitTest} disabled={userInput.length !== TOTAL_SYMBOLS}>
                Submit
              </Button>
            </div>
          )}
          {testState === "result" && (
            <div className="space-y-4">
              <p className="text-xl font-semibold">Your Attention Score:</p>
              <Progress value={score} className="w-full" />
              <p className="text-sm text-muted-foreground">Score: {score.toFixed(2)}%</p>
              <Button onClick={resetTest}>Try Again</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
