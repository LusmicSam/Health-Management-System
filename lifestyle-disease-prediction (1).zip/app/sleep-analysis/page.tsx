"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

export default function SleepAnalysis() {
  const [sleepData, setSleepData] = useState({
    bedtime: "22:00",
    wakeTime: "06:00",
    sleepQuality: 5,
    stressLevel: 5,
    exerciseMinutes: 30,
    caffeine: "low",
  })
  const [analysis, setAnalysis] = useState<string | null>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSleepData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setSleepData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSliderChange = (name: string, value: number[]) => {
    setSleepData((prev) => ({ ...prev, [name]: value[0] }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would be an API call to your ML model
    const response = await fetch("/api/analyze-sleep", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sleepData),
    })
    const data = await response.json()
    setAnalysis(data.analysis)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Sleep Pattern Analysis</h1>
      <Card>
        <CardHeader>
          <CardTitle>Your Sleep Data</CardTitle>
          <CardDescription>Provide information about your sleep habits</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedtime">Bedtime</Label>
                <Input id="bedtime" name="bedtime" type="time" value={sleepData.bedtime} onChange={handleInputChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wakeTime">Wake Time</Label>
                <Input
                  id="wakeTime"
                  name="wakeTime"
                  type="time"
                  value={sleepData.wakeTime}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sleepQuality">Sleep Quality (1-10)</Label>
              <Slider
                id="sleepQuality"
                min={1}
                max={10}
                step={1}
                value={[sleepData.sleepQuality]}
                onValueChange={(value) => handleSliderChange("sleepQuality", value)}
              />
              <p className="text-sm text-muted-foreground">{sleepData.sleepQuality}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="stressLevel">Stress Level (1-10)</Label>
              <Slider
                id="stressLevel"
                min={1}
                max={10}
                step={1}
                value={[sleepData.stressLevel]}
                onValueChange={(value) => handleSliderChange("stressLevel", value)}
              />
              <p className="text-sm text-muted-foreground">{sleepData.stressLevel}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="exerciseMinutes">Exercise Duration (minutes)</Label>
              <Input
                id="exerciseMinutes"
                name="exerciseMinutes"
                type="number"
                value={sleepData.exerciseMinutes}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="caffeine">Caffeine Intake</Label>
              <Select
                name="caffeine"
                value={sleepData.caffeine}
                onValueChange={(value) => handleSelectChange("caffeine", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select caffeine intake" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit">Analyze Sleep Pattern</Button>
          </form>
        </CardContent>
      </Card>

      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle>Sleep Analysis Result</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg">{analysis}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
