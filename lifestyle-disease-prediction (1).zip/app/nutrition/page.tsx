"use client"

import { useState } from "react"
import { Plus, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

// Mock data for food items
const foodDatabase = [
  { id: 1, name: "Apple", calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  { id: 2, name: "Chicken Breast", calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { id: 3, name: "Brown Rice", calories: 216, protein: 5, carbs: 45, fat: 1.6 },
  { id: 4, name: "Broccoli", calories: 55, protein: 3.7, carbs: 11.2, fat: 0.6 },
  { id: 5, name: "Salmon", calories: 206, protein: 22, carbs: 0, fat: 13 },
]

export default function NutritionTracking() {
  const [searchTerm, setSearchTerm] = useState("")
  const [meals, setMeals] = useState<Array<{ id: number; name: string; calories: number }>>([])

  const filteredFoods = foodDatabase.filter((food) => food.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const addFood = (food: { id: number; name: string; calories: number }) => {
    setMeals([...meals, food])
  }

  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0)
  const calorieGoal = 2000 // Example daily calorie goal

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Nutrition Tracking</h1>

      <Card>
        <CardHeader>
          <CardTitle>Add Food</CardTitle>
          <CardDescription>Search for food items to add to your daily log</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Search for food..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-grow"
            />
            <Button>
              <Search className="mr-2 h-4 w-4" /> Search
            </Button>
          </div>
          <div className="mt-4 space-y-2">
            {filteredFoods.map((food) => (
          <div key={food.id} className="flex justify-between items-center p-2 bg-gray-200 rounded">
          <span className="text-black font-medium">
            {food.name} - {food.calories} cal
          </span>
            <Button size="sm" onClick={() => addFood(food)}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Today's Meals</CardTitle>
          <CardDescription>Track your daily calorie intake</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {meals.map((meal, index) => (
              <li key={index} className="flex justify-between items-center">
                <span>{meal.name}</span>
                <span>{meal.calories} cal</span>
              </li>
            ))}
          </ul>
          <div className="mt-4">
            <p className="text-lg font-semibold">
              Total Calories: {totalCalories} / {calorieGoal}
            </p>
            <Progress value={(totalCalories / calorieGoal) * 100} className="mt-2" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
