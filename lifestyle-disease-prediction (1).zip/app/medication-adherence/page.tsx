"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

export default function MedicationAdherence() {
  const [medicationData, setMedicationData] = useState({
    medicationName: "",
    dosage: "",
    frequency: "once",
    timeOfDay: "morning",
    sideEffects: 1,
    importance: 5,
  })
  const [prediction, setPrediction] = useState<string | null>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setMedicationData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setMedicationData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSliderChange = (name: string, value: number[]) => {
    setMedicationData((prev) => ({ ...prev, [name]: value[0] }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would be an API call to your ML model
    const response = await fetch("/api/predict-adherence", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(medicationData),
    })
    const data = await response.json()
    setPrediction(data.prediction)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Medication Adherence Prediction</h1>
      <Card>
        <CardHeader>
          <CardTitle>Medication Details</CardTitle>
          <CardDescription>Provide information about your medication regimen</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="medicationName">Medication Name</Label>
              <Input
                id="medicationName"
                name="medicationName"
                value={medicationData.medicationName}
                onChange={handleInputChange}
                placeholder="Enter medication name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dosage">Dosage</Label>
              <Input
                id="dosage"
                name="dosage"
                value={medicationData.dosage}
                onChange={handleInputChange}
                placeholder="Enter dosage (e.g., 500mg)"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency</Label>
              <Select
                name="frequency"
                value={medicationData.frequency}
                onValueChange={(value) => handleSelectChange("frequency", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="once">Once daily</SelectItem>
                  <SelectItem value="twice">Twice daily</SelectItem>
                  <SelectItem value="thrice">Three times daily</SelectItem>
                  <SelectItem value="four">Four times daily</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="timeOfDay">Preferred Time of Day</Label>
              <Select
                name="timeOfDay"
                value={medicationData.timeOfDay}
                onValueChange={(value) => handleSelectChange("timeOfDay", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select time of day" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="evening">Evening</SelectItem>
                  <SelectItem value="night">Night</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sideEffects">Side Effects Severity (1-10)</Label>
              <Slider
                id="sideEffects"
                min={1}
                max={10}
                step={1}
                value={[medicationData.sideEffects]}
                onValueChange={(value) => handleSliderChange("sideEffects", value)}
              />
              <p className="text-sm text-muted-foreground">{medicationData.sideEffects}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="importance">Perceived Importance (1-10)</Label>
              <Slider
                id="importance"
                min={1}
                max={10}
                step={1}
                value={[medicationData.importance]}
                onValueChange={(value) => handleSliderChange("importance", value)}
              />
              <p className="text-sm text-muted-foreground">{medicationData.importance}</p>
            </div>
            <Button type="submit">Predict Adherence</Button>
          </form>
        </CardContent>
      </Card>

      {prediction && (
        <Card>
          <CardHeader>
            <CardTitle>Adherence Prediction</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg">{prediction}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
