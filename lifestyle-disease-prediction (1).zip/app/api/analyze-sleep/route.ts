import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const { bedtime, wakeTime, sleepQuality, stressLevel, exerciseMinutes, caffeine } = await req.json()

  try {
    // Instead of mock implementation, make a real API call
    const apiKey = process.env.GOOGLE_API_KEY

    // Prepare the data for the external API
    const apiData = {
      bedtime,
      wakeTime,
      sleepQuality,
      stressLevel,
      exerciseMinutes,
      caffeine,
    }

    // For now, we'll still use the mock sleep analysis logic
    // In a production app, you would replace this with a real API call
    const analysis = mockSleepAnalysis({ bedtime, wakeTime, sleepQuality, stressLevel, exerciseMinutes, caffeine })

    return NextResponse.json({ analysis })
  } catch (error) {
    console.error("Error analyzing sleep:", error)
    return NextResponse.json({ error: "Failed to analyze sleep" }, { status: 500 })
  }
}

// This function would be replaced with a real API call in production
const mockSleepAnalysis = (data: any) => {
  let analysis = "Based on your sleep data:\n\n"

  // Calculate sleep duration
  const bedtimeDate = new Date(`2000-01-01T${data.bedtime}:00`)
  const wakeTimeDate = new Date(`2000-01-01T${data.wakeTime}:00`)
  if (wakeTimeDate < bedtimeDate) wakeTimeDate.setDate(wakeTimeDate.getDate() + 1)
  const sleepDuration = (wakeTimeDate.getTime() - bedtimeDate.getTime()) / (1000 * 60 * 60)

  if (sleepDuration < 7) {
    analysis += "- You're not getting enough sleep. Aim for 7-9 hours per night.\n"
  } else if (sleepDuration > 9) {
    analysis += "- You might be oversleeping. Try to maintain a consistent sleep schedule.\n"
  } else {
    analysis += "- Your sleep duration is within the recommended range.\n"
  }

  if (data.sleepQuality < 5) {
    analysis += "- Your sleep quality is poor. Consider improving your sleep environment.\n"
  } else if (data.sleepQuality > 7) {
    analysis += "- You're experiencing good sleep quality. Keep up your current habits.\n"
  }

  if (data.stressLevel > 7) {
    analysis += "- High stress levels may be affecting your sleep. Try stress-reduction techniques.\n"
  }

  if (data.exerciseMinutes < 30) {
    analysis += "- Increasing your daily exercise may improve your sleep quality.\n"
  } else {
    analysis += "- Your exercise habits are likely benefiting your sleep.\n"
  }

  if (data.caffeine === "high") {
    analysis +=
      "- High caffeine intake may be disrupting your sleep. Consider reducing consumption, especially in the afternoon and evening.\n"
  }

  return analysis
}
