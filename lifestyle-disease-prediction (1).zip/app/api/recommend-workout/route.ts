import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const { fitnessLevel, workoutDuration, workoutType } = await req.json()

  try {
    // Instead of mock implementation, make a real API call
    const apiKey = process.env.GOOGLE_API_KEY

    // Prepare the data for the external API
    const apiData = {
      fitnessLevel,
      workoutDuration,
      workoutType,
    }

    // For now, we'll still use the mock recommendations logic
    // In a production app, you would replace this with a real API call
    const recommendations = mockRecommendations(fitnessLevel, workoutDuration, workoutType)

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error("Error recommending workout:", error)
    return NextResponse.json({ error: "Failed to recommend workout" }, { status: 500 })
  }
}

// This function would be replaced with a real API call in production
const mockRecommendations = (fitnessLevel: string, workoutDuration: number, workoutType: string) => {
  const recommendations = []

  if (workoutType === "cardio") {
    if (fitnessLevel === "beginner") {
      recommendations.push(`Start with a ${Math.min(10, workoutDuration)} minute brisk walk`)
      if (workoutDuration > 10) recommendations.push(`Follow with ${workoutDuration - 10} minutes of light jogging`)
    } else if (fitnessLevel === "intermediate") {
      recommendations.push(`Warm up with a 5 minute jog`)
      recommendations.push(`Do ${workoutDuration - 10} minutes of interval running (1 minute sprint, 1 minute jog)`)
      recommendations.push(`Cool down with a 5 minute walk`)
    } else {
      recommendations.push(`Warm up with a 5 minute jog`)
      recommendations.push(`Do ${workoutDuration - 10} minutes of high-intensity interval training`)
      recommendations.push(`Cool down with a 5 minute jog`)
    }
  } else if (workoutType === "strength") {
    const exercises =
      fitnessLevel === "beginner"
        ? ["bodyweight squats", "push-ups", "lunges", "plank holds"]
        : ["barbell squats", "bench press", "deadlifts", "pull-ups"]
    recommendations.push(`Perform 3 sets of each exercise:`)
    exercises.forEach((exercise) =>
      recommendations.push(`- ${exercise}: ${fitnessLevel === "beginner" ? "10 reps" : "8-12 reps"}`),
    )
  } else if (workoutType === "flexibility") {
    recommendations.push(`Start with 5 minutes of light cardio to warm up`)
    recommendations.push(`Hold each stretch for 15-30 seconds:`)
    recommendations.push(`- Hamstring stretch`)
    recommendations.push(`- Quad stretch`)
    recommendations.push(`- Shoulder stretch`)
    recommendations.push(`- Lower back stretch`)
  } else if (workoutType === "hiit") {
    recommendations.push(`Warm up for 5 minutes with light cardio`)
    recommendations.push(`Perform the following circuit for ${Math.floor(workoutDuration / 5)} rounds:`)
    recommendations.push(`- 30 seconds of burpees`)
    recommendations.push(`- 30 seconds of mountain climbers`)
    recommendations.push(`- 30 seconds of jump squats`)
    recommendations.push(`- 30 seconds of rest`)
    recommendations.push(`Cool down with 5 minutes of light stretching`)
  }

  return recommendations
}
