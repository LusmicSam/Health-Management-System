import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const data = await req.json()

  try {
    // Instead of mock implementation, make a real API call
    const apiKey = process.env.GOOGLE_API_KEY

    // Prepare the data for the external API
    const apiData = {
      age: data.age,
      gender: data.gender,
      bmi: data.bmi,
      bloodPressure: data.bloodPressure,
      cholesterol: data.cholesterol,
      glucose: data.glucose,
      smoking: data.smoking === "yes" ? 1 : 0,
      alcohol: data.alcohol === "yes" ? 1 : 0,
      physicalActivity: data.physicalActivity,
    }

    // For now, we'll still use the mock prediction logic
    // In a production app, you would replace this with a real API call
    const prediction = mockPrediction(apiData)

    return NextResponse.json({ prediction })
  } catch (error) {
    console.error("Error predicting risk:", error)
    return NextResponse.json({ error: "Failed to predict risk" }, { status: 500 })
  }
}

// This function would be replaced with a real API call in production
const mockPrediction = (data: any) => {
  const riskFactors = [
    data.age > 50,
    data.bmi > 30,
    data.bloodPressure > 140,
    data.cholesterol > 240,
    data.glucose > 126,
    data.smoking === 1,
    data.alcohol === 1,
    data.physicalActivity < 2,
  ]

  const riskScore = riskFactors.filter(Boolean).length

  if (riskScore <= 2) {
    return "Low risk of cardiovascular disease."
  } else if (riskScore <= 4) {
    return "Moderate risk of cardiovascular disease. Consider lifestyle changes."
  } else {
    return "High risk of cardiovascular disease. Consult with a healthcare professional."
  }
}
