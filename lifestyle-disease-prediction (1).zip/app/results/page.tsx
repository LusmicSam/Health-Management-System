"use client"

import { useEffect, useState, useCallback } from "react"
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface AssessmentData {
  age: number
  gender: string
  height: number
  weight: number
  bmi: string
  smokingStatus: string
  alcoholConsumption: string
  physicalActivity: string
  familyHistoryDiabetes: boolean
  familyHistoryHeartDisease: boolean
  familyHistoryHypertension: boolean
  familyHistoryAsthma: boolean
  familyHistoryObesity: boolean
  familyHistoryDepression: boolean
  familyHistoryArthritis: boolean
  systolicBP: number
  diastolicBP: number
  allergies: string
  chronicPain: string
  mentalHealthHistory: string
  [key: string]: any
}

interface RiskData {
  disease: string
  risk: number
}

export default function Results() {
  const [progress, setProgress] = useState(0)
  const [riskData, setRiskData] = useState<RiskData[]>([])
  const [recommendations, setRecommendations] = useState<string[]>([])
  const [assessmentData, setAssessmentData] = useState<AssessmentData | null>(null)
  const [loading, setLoading] = useState(true)
  const [analysisProgress, setAnalysisProgress] = useState(0)

  const calculateRisk = useCallback((disease: string, data: AssessmentData): number => {
    let risk = 0

    switch (disease) {
      case "Diabetes":
        if (data.age > 45) risk += 10
        if (Number(data.bmi) > 30) risk += 15
        if (data.familyHistoryDiabetes) risk += 15
        if (data.physicalActivity === "sedentary") risk += 10
        break
      case "Heart Disease":
        if (data.age > 55) risk += 10
        if (data.systolicBP > 140 || data.diastolicBP > 90) risk += 15
        if (data.familyHistoryHeartDisease) risk += 15
        if (data.smokingStatus === "current") risk += 15
        break
      case "Hypertension":
        if (data.systolicBP > 140 || data.diastolicBP > 90) risk += 20
        if (data.familyHistoryHypertension) risk += 15
        if (data.alcoholConsumption === "heavy") risk += 10
        break
      case "Obesity":
        if (Number(data.bmi) > 30) risk += 30
        if (data.physicalActivity === "sedentary") risk += 15
        if (data.familyHistoryObesity) risk += 10
        break
      case "Asthma":
        if (data.familyHistoryAsthma) risk += 20
        if (data.smokingStatus === "current") risk += 15
        if (data.allergies.includes("Pollen") || data.allergies.includes("Dust")) risk += 10
        break
      case "Depression":
        if (data.familyHistoryDepression) risk += 15
        if (data.stressLevel > 7) risk += 15
        if (data.sleepQuality === "poor") risk += 10
        if (data.mentalHealthHistory.includes("Depression") || data.mentalHealthHistory.includes("Anxiety")) risk += 20
        break
      case "Arthritis":
        if (data.age > 50) risk += 15
        if (data.familyHistoryArthritis) risk += 15
        if (data.chronicPain === "moderate" || data.chronicPain === "severe") risk += 20
        if (Number(data.bmi) > 30) risk += 10
        break
    }

    return Math.min(risk, 100)
  }, [])

  const generateRecommendations = useCallback((data: AssessmentData): string[] => {
    const recommendations: string[] = []

    if (data.physicalActivity === "sedentary" || data.physicalActivity === "light") {
      recommendations.push("Increase your daily physical activity to at least 30 minutes of moderate exercise.")
    }

    if (data.dailyFruitVegServings < 5) {
      recommendations.push("Increase your daily intake of fruits and vegetables to at least 5 servings.")
    }

    if (data.dailyWaterIntake < 2000) {
      recommendations.push("Increase your daily water intake to at least 2 liters (2000ml).")
    }

    if (data.sleepDuration < 7 || data.sleepQuality === "poor" || data.sleepQuality === "fair") {
      recommendations.push("Aim for 7-9 hours of quality sleep per night to improve overall health.")
    }

    if (data.stressLevel > 7) {
      recommendations.push("Practice stress-reduction techniques such as meditation or deep breathing exercises.")
    }

    if (data.smokingStatus === "current") {
      recommendations.push(
        "Consider quitting smoking to significantly reduce your risk of heart disease and other health problems.",
      )
    }

    if (data.alcoholConsumption === "heavy") {
      recommendations.push("Reduce alcohol consumption to moderate levels or consider abstaining completely.")
    }

    if (Number(data.bmi) > 25) {
      recommendations.push("Work on maintaining a healthy weight through a balanced diet and regular exercise.")
    }

    if (data.chronicPain !== "none") {
      recommendations.push(
        "Consult with a healthcare professional about managing your chronic pain and consider physical therapy or pain management techniques.",
      )
    }

    if (data.mentalHealthHistory !== "") {
      recommendations.push(
        "Continue to prioritize your mental health. Consider regular check-ins with a mental health professional.",
      )
    }

    return recommendations
  }, [])

  useEffect(() => {
    const storedData = localStorage.getItem("assessmentData")
    if (storedData) {
      const data = JSON.parse(storedData) as AssessmentData
      setAssessmentData(data)

      const simulateAnalysis = async () => {
        const diseases = ["Diabetes", "Heart Disease", "Hypertension", "Obesity", "Asthma", "Depression", "Arthritis"]
        const updatedRiskData: RiskData[] = []

        for (let i = 0; i < diseases.length; i++) {
          await new Promise((resolve) => setTimeout(resolve, 1000))
          const risk = calculateRisk(diseases[i], data)
          updatedRiskData.push({ disease: diseases[i], risk })
          setAnalysisProgress(((i + 1) / diseases.length) * 100)
        }

        const healthScore = Math.round(
          85 * (1 - updatedRiskData.reduce((acc, curr) => acc + curr.risk, 0) / (updatedRiskData.length * 100)),
        )
        setProgress(healthScore)
        setRiskData(updatedRiskData)
        setRecommendations(generateRecommendations(data))
        setLoading(false)
      }

      simulateAnalysis()
    }
  }, [calculateRisk, generateRecommendations])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin mb-4" />
        <span className="text-lg mb-2">Analyzing your health data...</span>
        <Progress value={analysisProgress} className="w-1/2 max-w-md" />
      </div>
    )
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <Card>
        <CardHeader>
          <CardTitle>Your Health Risk Assessment</CardTitle>
          <CardDescription>Based on the information you provided, here's your health risk overview.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskData}>
                <XAxis dataKey="disease" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="risk">
                  {riskData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={`hsl(${120 - entry.risk * 1.2}, 70%, 50%)`} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Health Risk Radar</CardTitle>
          <CardDescription>A different perspective on your health risks.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={riskData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="disease" />
                <PolarRadiusAxis angle={30} domain={[0, 100]} />
                <Radar name="Risk" dataKey="risk" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Overall Health Score</CardTitle>
          <CardDescription>Your health score based on various factors.</CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="w-full" />
          <p className="mt-2 text-sm text-muted-foreground">Your health score: {progress}/100</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recommendations</CardTitle>
          <CardDescription>Here are some suggestions to improve your health:</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            {recommendations.map((recommendation, index) => (
              <li key={index} className="animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                {recommendation}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button asChild>
          <a href="/assessment">Retake Assessment</a>
        </Button>
      </div>
    </div>
  )
}
