"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"

export default function WorkoutRecommendations() {
  const [fitnessLevel, setFitnessLevel] = useState("beginner")
  const [workoutDuration, setWorkoutDuration] = useState(30)
  const [workoutType, setWorkoutType] = useState("cardio")
  const [recommendations, setRecommendations] = useState<string[] | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would be an API call to your ML model
    const response = await fetch("/api/recommend-workout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fitnessLevel, workoutDuration, workoutType }),
    })
    const data = await response.json()
    setRecommendations(data.recommendations)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Personalized Workout Recommendations</h1>
      <Card>
        <CardHeader>
          <CardTitle>Your Workout Preferences</CardTitle>
          <CardDescription>Tell us about your fitness level and goals</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fitnessLevel">Fitness Level</Label>
              <Select name="fitnessLevel" value={fitnessLevel} onValueChange={(value) => setFitnessLevel(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select fitness level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="workoutDuration">Workout Duration (minutes)</Label>
              <Slider
                id="workoutDuration"
                min={10}
                max={120}
                step={5}
                value={[workoutDuration]}
                onValueChange={(value) => setWorkoutDuration(value[0])}
              />
              <p className="text-sm text-muted-foreground">{workoutDuration} minutes</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="workoutType">Workout Type</Label>
              <Select name="workoutType" value={workoutType} onValueChange={(value) => setWorkoutType(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select workout type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cardio">Cardio</SelectItem>
                  <SelectItem value="strength">Strength Training</SelectItem>
                  <SelectItem value="flexibility">Flexibility</SelectItem>
                  <SelectItem value="hiit">HIIT</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit">Get Recommendations</Button>
          </form>
        </CardContent>
      </Card>

      {recommendations && (
        <Card>
          <CardHeader>
            <CardTitle>Your Personalized Workout Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              {recommendations.map((recommendation, index) => (
                <li key={index}>{recommendation}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
