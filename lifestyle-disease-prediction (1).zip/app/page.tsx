import type React from "react"
import Link from "next/link"
import { ArrowRight, Activity, Users, Watch, Brain, Utensils, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="text-center py-20 bg-gradient-to-r from-gray-900 to-gray-700 text-white rounded-lg">
        <h1 className="text-5xl font-bold mb-4">HealthPredict AI</h1>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Harness the power of AI to predict, prevent, and improve your health. Your personal health companion for a
          better tomorrow.
        </p>
        <div className="flex justify-center space-x-4">
          <Button asChild size="lg" variant="default">
            <Link href="/assessment">
              Start Health Assessment <ArrowRight className="ml-2" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/demo">Watch Demo</Link>
          </Button>
        </div>
      </section>

      <section className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold mb-8 text-center">Why Choose HealthPredict AI?</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon={Brain}
            title="AI-Powered Analysis"
            description="Our advanced algorithms provide accurate health predictions and personalized recommendations based on your unique profile."
          />
          <FeatureCard
            icon={Watch}
            title="Wearable Integration"
            description="Seamlessly connect your fitness devices for real-time health tracking and insights."
          />
          <FeatureCard
            icon={Users}
            title="Community Support"
            description="Join a community of health-conscious individuals and participate in challenges to stay motivated."
          />
        </div>
      </section>

      <section className="bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 py-16 rounded-lg">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-semibold mb-8 text-center">Comprehensive Health Management</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <FeatureCard
              icon={Activity}
              title="Health Tracking"
              description="Monitor your vital signs and health metrics over time"
            />
            <FeatureCard
              icon={Brain}
              title="Mental Wellness"
              description="Assess and improve your mental health with AI-driven tools"
            />
            <FeatureCard
              icon={Utensils}
              title="Nutrition Planning"
              description="Get personalized meal plans and nutrition advice"
            />
            <FeatureCard
              icon={Heart}
              title="Disease Prevention"
              description="Identify and mitigate potential health risks early"
            />
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-semibold mb-8 text-center">Take Control of Your Health Journey</h2>
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=600&h=400&auto=format&fit=crop"
              alt="AI analyzing health data with medical charts and visualization"
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-semibold">Your Path to Wellness Starts Here</h3>
            <p>
              HealthPredict AI empowers you with the knowledge and tools to make informed decisions about your health.
              Our comprehensive platform combines cutting-edge AI technology with personalized insights to guide you
              towards a healthier lifestyle.
            </p>
            <ul className="space-y-2">
              <li className="flex items-center">
                <ArrowRight className="mr-2 text-primary" /> Personalized health assessments
              </li>
              <li className="flex items-center">
                <ArrowRight className="mr-2 text-primary" /> AI-driven health predictions
              </li>
              <li className="flex items-center">
                <ArrowRight className="mr-2 text-primary" /> Customized wellness plans
              </li>
              <li className="flex items-center">
                <ArrowRight className="mr-2 text-primary" /> Continuous health monitoring
              </li>
            </ul>
            <Button asChild size="lg" className="mt-4">
              <Link href="/signup">Start Your Journey</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-r from-gray-900 to-gray-700 text-white py-16 rounded-lg">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-semibold mb-4">Join 100,000+ Users Improving Their Health with AI</h2>
          <p className="text-xl mb-8">Experience the future of preventive healthcare today</p>
          <Button asChild size="lg" variant="secondary">
            <Link href="/signup">Sign Up for Free</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

function FeatureCard({
  icon: Icon,
  title,
  description,
}: { icon: React.ElementType; title: string; description: string }) {
  return (
    <Card className="transition-all duration-300 hover:shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Icon className="mr-2 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p>{description}</p>
      </CardContent>
    </Card>
  )
}
