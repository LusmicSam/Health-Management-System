"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { ArrowRight, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const formSchema = z.object({
  // Basic Information
  age: z.number().min(0).max(120),
  gender: z.enum(["male", "female", "other"]),
  height: z.number().min(100).max(250),
  weight: z.number().min(30).max(300),

  // Lifestyle
  smokingStatus: z.enum(["never", "former", "current"]),
  alcoholConsumption: z.enum(["none", "moderate", "heavy"]),
  physicalActivity: z.enum(["sedentary", "light", "moderate", "vigorous"]),
  dietType: z.enum(["balanced", "high-carb", "high-protein", "vegetarian", "vegan"]),

  // Medical History
  familyHistoryDiabetes: z.boolean(),
  familyHistoryHeartDisease: z.boolean(),
  familyHistoryHypertension: z.boolean(),
  previousDiagnoses: z.string(),

  // Vital Signs
  systolicBP: z.number().min(70).max(220),
  diastolicBP: z.number().min(40).max(130),
  restingHeartRate: z.number().min(40).max(120),

  // Mental Health
  stressLevel: z.number().min(1).max(10),
  sleepQuality: z.enum(["poor", "fair", "good", "excellent"]),
  sleepDuration: z.number().min(3).max(12),

  // Nutrition
  dailyWaterIntake: z.number().min(0).max(5000),
  dailyFruitVegServings: z.number().min(0).max(10),

  // Additional Metrics
  waistCircumference: z.number().min(50).max(200),
  bodyFatPercentage: z.number().min(5).max(50),

  // Additional fields for new diseases
  familyHistoryAsthma: z.boolean(),
  familyHistoryObesity: z.boolean(),
  familyHistoryDepression: z.boolean(),
  familyHistoryArthritis: z.boolean(),
  allergies: z.string(),
  chronicPain: z.enum(["none", "mild", "moderate", "severe"]),
  mentalHealthHistory: z.string(),
})

const steps = [
  { title: "Basic Information", fields: ["age", "gender", "height", "weight"] },
  { title: "Lifestyle", fields: ["smokingStatus", "alcoholConsumption", "physicalActivity", "dietType"] },
  {
    title: "Medical History",
    fields: ["familyHistoryDiabetes", "familyHistoryHeartDisease", "familyHistoryHypertension", "previousDiagnoses"],
  },
  { title: "Vital Signs", fields: ["systolicBP", "diastolicBP", "restingHeartRate"] },
  { title: "Mental Health", fields: ["stressLevel", "sleepQuality", "sleepDuration"] },
  { title: "Nutrition", fields: ["dailyWaterIntake", "dailyFruitVegServings"] },
  { title: "Additional Metrics", fields: ["waistCircumference", "bodyFatPercentage"] },
  {
    title: "Additional Health Information",
    fields: [
      "familyHistoryAsthma",
      "familyHistoryObesity",
      "familyHistoryDepression",
      "familyHistoryArthritis",
      "allergies",
      "chronicPain",
      "mentalHealthHistory",
    ],
  },
]

export default function HealthAssessment() {
  const [currentStep, setCurrentStep] = useState(0)
  const router = useRouter()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: 30,
      gender: "male",
      height: 170,
      weight: 70,
      smokingStatus: "never",
      alcoholConsumption: "moderate",
      physicalActivity: "moderate",
      dietType: "balanced",
      familyHistoryDiabetes: false,
      familyHistoryHeartDisease: false,
      familyHistoryHypertension: false,
      previousDiagnoses: "",
      systolicBP: 120,
      diastolicBP: 80,
      restingHeartRate: 70,
      stressLevel: 5,
      sleepQuality: "good",
      sleepDuration: 7,
      dailyWaterIntake: 2000,
      dailyFruitVegServings: 3,
      waistCircumference: 80,
      bodyFatPercentage: 20,
      familyHistoryAsthma: false,
      familyHistoryObesity: false,
      familyHistoryDepression: false,
      familyHistoryArthritis: false,
      allergies: "",
      chronicPain: "none",
      mentalHealthHistory: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      // In a real application, you would send this data to your backend
      // and then redirect to the results page

      // Calculate BMI
      const heightInMeters = values.height / 100
      const bmi = values.weight / (heightInMeters * heightInMeters)

      // Store the assessment data in localStorage for the results page
      localStorage.setItem(
        "assessmentData",
        JSON.stringify({
          ...values,
          bmi: bmi.toFixed(1),
        }),
      )

      // Redirect to results page
      router.push("/results")
    } catch (error) {
      console.error("Error submitting assessment:", error)
    }
  }

  const currentFields = steps[currentStep].fields

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Comprehensive Health Assessment</h1>
      <Card>
        <CardHeader>
          <CardTitle>{steps[currentStep].title}</CardTitle>
          <CardDescription>
            Step {currentStep + 1} of {steps.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {currentFields.includes("age") && (
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Your age in years.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("gender") && (
                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gender</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your gender" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("height") && (
                <FormField
                  control={form.control}
                  name="height"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Height (cm)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("weight") && (
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weight (kg)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("smokingStatus") && (
                <FormField
                  control={form.control}
                  name="smokingStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Smoking Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your smoking status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="never">Never smoked</SelectItem>
                          <SelectItem value="former">Former smoker</SelectItem>
                          <SelectItem value="current">Current smoker</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("alcoholConsumption") && (
                <FormField
                  control={form.control}
                  name="alcoholConsumption"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Alcohol Consumption</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your alcohol consumption" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="heavy">Heavy</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("physicalActivity") && (
                <FormField
                  control={form.control}
                  name="physicalActivity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Physical Activity Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your activity level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sedentary">Sedentary</SelectItem>
                          <SelectItem value="light">Light</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="vigorous">Vigorous</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("dietType") && (
                <FormField
                  control={form.control}
                  name="dietType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Diet Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your diet type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="balanced">Balanced</SelectItem>
                          <SelectItem value="high-carb">High Carb</SelectItem>
                          <SelectItem value="high-protein">High Protein</SelectItem>
                          <SelectItem value="vegetarian">Vegetarian</SelectItem>
                          <SelectItem value="vegan">Vegan</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryDiabetes") && (
                <FormField
                  control={form.control}
                  name="familyHistoryDiabetes"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Diabetes</FormLabel>
                        <FormDescription>Do you have a family history of diabetes?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryHeartDisease") && (
                <FormField
                  control={form.control}
                  name="familyHistoryHeartDisease"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Heart Disease</FormLabel>
                        <FormDescription>Do you have a family history of heart disease?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryHypertension") && (
                <FormField
                  control={form.control}
                  name="familyHistoryHypertension"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Hypertension</FormLabel>
                        <FormDescription>Do you have a family history of hypertension?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("previousDiagnoses") && (
                <FormField
                  control={form.control}
                  name="previousDiagnoses"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Previous Diagnoses</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Asthma, Arthritis" />
                      </FormControl>
                      <FormDescription>List any previous medical diagnoses, separated by commas.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("systolicBP") && (
                <FormField
                  control={form.control}
                  name="systolicBP"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Systolic Blood Pressure</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>The top number in a blood pressure reading.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("diastolicBP") && (
                <FormField
                  control={form.control}
                  name="diastolicBP"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Diastolic Blood Pressure</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>The bottom number in a blood pressure reading.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("restingHeartRate") && (
                <FormField
                  control={form.control}
                  name="restingHeartRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Resting Heart Rate</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Your heart rate when you're at complete rest.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("stressLevel") && (
                <FormField
                  control={form.control}
                  name="stressLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stress Level (1-10)</FormLabel>
                      <FormControl>
                        <Slider
                          min={1}
                          max={10}
                          step={1}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                        />
                      </FormControl>
                      <FormDescription>1 being the lowest, 10 being the highest.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("sleepQuality") && (
                <FormField
                  control={form.control}
                  name="sleepQuality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sleep Quality</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="poor" />
                            </FormControl>
                            <FormLabel className="font-normal">Poor</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="fair" />
                            </FormControl>
                            <FormLabel className="font-normal">Fair</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="good" />
                            </FormControl>
                            <FormLabel className="font-normal">Good</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="excellent" />
                            </FormControl>
                            <FormLabel className="font-normal">Excellent</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("sleepDuration") && (
                <FormField
                  control={form.control}
                  name="sleepDuration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sleep Duration (hours)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseFloat(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Average number of hours you sleep per night.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("dailyWaterIntake") && (
                <FormField
                  control={form.control}
                  name="dailyWaterIntake"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Daily Water Intake (ml)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Average amount of water you drink per day in milliliters.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("dailyFruitVegServings") && (
                <FormField
                  control={form.control}
                  name="dailyFruitVegServings"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Daily Fruit and Vegetable Servings</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Number of fruit and vegetable servings you eat per day.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("waistCircumference") && (
                <FormField
                  control={form.control}
                  name="waistCircumference"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Waist Circumference (cm)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("bodyFatPercentage") && (
                <FormField
                  control={form.control}
                  name="bodyFatPercentage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Body Fat Percentage</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseFloat(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>Your estimated body fat percentage.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryAsthma") && (
                <FormField
                  control={form.control}
                  name="familyHistoryAsthma"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Asthma</FormLabel>
                        <FormDescription>Do you have a family history of asthma?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryObesity") && (
                <FormField
                  control={form.control}
                  name="familyHistoryObesity"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Obesity</FormLabel>
                        <FormDescription>Do you have a family history of obesity?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryDepression") && (
                <FormField
                  control={form.control}
                  name="familyHistoryDepression"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Depression</FormLabel>
                        <FormDescription>Do you have a family history of depression?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("familyHistoryArthritis") && (
                <FormField
                  control={form.control}
                  name="familyHistoryArthritis"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Family History of Arthritis</FormLabel>
                        <FormDescription>Do you have a family history of arthritis?</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("allergies") && (
                <FormField
                  control={form.control}
                  name="allergies"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Allergies</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Pollen, Peanuts, Dairy" />
                      </FormControl>
                      <FormDescription>List any allergies you have, separated by commas.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("chronicPain") && (
                <FormField
                  control={form.control}
                  name="chronicPain"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Chronic Pain Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your chronic pain level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="mild">Mild</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="severe">Severe</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {currentFields.includes("mentalHealthHistory") && (
                <FormField
                  control={form.control}
                  name="mentalHealthHistory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mental Health History</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Anxiety, Depression" />
                      </FormControl>
                      <FormDescription>
                        List any mental health conditions you have or have had in the past.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                >
                  <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                </Button>
                {currentStep === steps.length - 1 ? (
                  <Button type="submit">Submit</Button>
                ) : (
                  <Button type="button" onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}>
                    Next <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
