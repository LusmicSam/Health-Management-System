"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ThumbsUp, MessageSquare, Share2 } from "lucide-react"

const challenges = [
  { name: "30-Day Fitness Challenge", participants: 1234, daysLeft: 7 },
  { name: "Healthy Eating Week", participants: 567, daysLeft: 3 },
  { name: "Stress Reduction Month", participants: 890, daysLeft: 21 },
]

const initialPosts = [
  {
    id: 1,
    author: "Jane Doe",
    avatar: "JD",
    content: "Just completed my first 5K run! Feeling great!",
    likes: 24,
    comments: 5,
  },
  {
    id: 2,
    author: "John Smith",
    avatar: "JS",
    content: "Anyone have tips for reducing sugar cravings?",
    likes: 18,
    comments: 12,
  },
  {
    id: 3,
    author: "Alice Johnson",
    avatar: "AJ",
    content: "Meditation has really helped lower my stress levels. Highly recommend!",
    likes: 32,
    comments: 8,
  },
]

export default function Community() {
  const [posts, setPosts] = useState(initialPosts)
  const [newPost, setNewPost] = useState("")

  const handleNewPost = () => {
    if (newPost.trim()) {
      const post = {
        id: posts.length + 1,
        author: "You",
        avatar: "YO",
        content: newPost,
        likes: 0,
        comments: 0,
      }
      setPosts([post, ...posts])
      setNewPost("")
    }
  }

  const handleLike = (postId: number) => {
    setPosts(posts.map((post) => (post.id === postId ? { ...post, likes: post.likes + 1 } : post)))
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Community</h1>

      <Card>
        <CardHeader>
          <CardTitle>Share Your Thoughts</CardTitle>
          <CardDescription>Inspire and connect with others on their health journey</CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="What's on your mind?"
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            className="mb-4"
          />
          <Button onClick={handleNewPost}>Post</Button>
        </CardContent>
      </Card>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Active Challenges</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {challenges.map((challenge) => (
            <Card key={challenge.name}>
              <CardHeader>
                <CardTitle>{challenge.name}</CardTitle>
                <CardDescription>{challenge.participants} participants</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{challenge.daysLeft} days left</p>
                <Button>Join Challenge</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Community Posts</h2>
        <div className="space-y-6">
          {posts.map((post) => (
            <Card key={post.id}>
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${post.avatar}`} />
                    <AvatarFallback>{post.avatar}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle>{post.author}</CardTitle>
                    <CardDescription>Just now</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{post.content}</p>
                <div className="flex space-x-4 text-sm text-gray-500">
                  <Button variant="ghost" size="sm" onClick={() => handleLike(post.id)}>
                    <ThumbsUp className="mr-2 h-4 w-4" />
                    {post.likes} Likes
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    {post.comments} Comments
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
