import type React from "react"
import "@/styles/globals.css"
import { Inter } from "next/font/google"
import Link from "next/link"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ThemeProvider } from "@/components/theme-provider"
import { ModeToggle } from "@/components/mode-toggle"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn("min-h-screen bg-background font-sans antialiased", inter.className)}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <div className="flex flex-col min-h-screen">
            <header className="border-b">
              <div className="container mx-auto px-4 py-4">
                <nav className="flex flex-wrap justify-between items-center">
                  <Link href="/" className="text-2xl font-bold">
                    HealthPredict AI
                  </Link>
                  <ul className="flex flex-wrap space-x-4 items-center">
                    <li>
                      <Link href="/assessment" className="hover:text-primary transition-colors">
                        Assessment
                      </Link>
                    </li>
                    <li>
                      <Link href="/dashboard" className="hover:text-primary transition-colors">
                        Dashboard
                      </Link>
                    </li>
                    <li>
                      <Link href="/risk-prediction" className="hover:text-primary transition-colors">
                        Risk Prediction
                      </Link>
                    </li>
                    <li>
                      <Link href="/workout-recommendations" className="hover:text-primary transition-colors">
                        Workout Plans
                      </Link>
                    </li>
                    <li>
                      <Link href="/symptom-checker" className="hover:text-primary transition-colors">
                        Symptom Checker
                      </Link>
                    </li>
                    <li>
                      <Link href="/sleep-analysis" className="hover:text-primary transition-colors">
                        Sleep Analysis
                      </Link>
                    </li>
                    <li>
                      <Link href="/medication-adherence" className="hover:text-primary transition-colors">
                        Medication Adherence
                      </Link>
                    </li>
                    <li>
                      <Link href="/nutrition" className="hover:text-primary transition-colors">
                        Nutrition
                      </Link>
                    </li>
                    <li>
                      <Link href="/community" className="hover:text-primary transition-colors">
                        Community
                      </Link>
                    </li>
                    <li>
                      <Link href="/resources" className="hover:text-primary transition-colors">
                        Resources
                      </Link>
                    </li>
                    <li>
                      <ModeToggle />
                    </li>
                    <li>
                      <Button asChild variant="outline">
                        <Link href="/login">Login</Link>
                      </Button>
                    </li>
                  </ul>
                </nav>
              </div>
            </header>
            <main className="flex-grow container mx-auto px-4 py-8">{children}</main>
            <footer className="border-t">
              <div className="container mx-auto px-4 py-6 text-center">
                <p>&copy; 2025 HealthPredict AI. All rights reserved.</p>
                <div className="mt-2">
                  <Link href="/privacy" className="text-primary hover:text-primary/80 mr-4">
                    Privacy Policy
                  </Link>
                  <Link href="/terms" className="text-primary hover:text-primary/80">
                    Terms of Service
                  </Link>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

export const metadata = {
      generator: 'v0.dev'
    };
