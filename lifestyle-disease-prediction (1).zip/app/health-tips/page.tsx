"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

const healthTips = [
  {
    id: 1,
    title: "Stay Hydrated",
    description: "Drink at least 8 glasses of water a day to maintain proper hydration.",
    category: "Nutrition",
  },
  {
    id: 2,
    title: "Regular Exercise",
    description: "Aim for at least 30 minutes of moderate exercise 5 days a week.",
    category: "Fitness",
  },
  {
    id: 3,
    title: "Mindful Meditation",
    description: "Practice 10 minutes of mindfulness meditation daily to reduce stress.",
    category: "Mental Health",
  },
  {
    id: 4,
    title: "Balanced Diet",
    description: "Include a variety of fruits, vegetables, whole grains, and lean proteins in your diet.",
    category: "Nutrition",
  },
  {
    id: 5,
    title: "Quality Sleep",
    description: "Aim for 7-9 hours of quality sleep each night to support overall health.",
    category: "Lifestyle",
  },
  {
    id: 6,
    title: "Stress Management",
    description: "Find healthy ways to manage stress, such as deep breathing or yoga.",
    category: "Mental Health",
  },
]

export default function HealthTips() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [completedTips, setCompletedTips] = useState<number[]>([])

  const categories = Array.from(new Set(healthTips.map((tip) => tip.category)))

  const filteredTips =
    selectedCategories.length > 0 ? healthTips.filter((tip) => selectedCategories.includes(tip.category)) : healthTips

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const toggleTipCompletion = (tipId: number) => {
    setCompletedTips((prev) => (prev.includes(tipId) ? prev.filter((id) => id !== tipId) : [...prev, tipId]))
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Personalized Health Tips</h1>

      <Card>
        <CardHeader>
          <CardTitle>Filter Tips</CardTitle>
          <CardDescription>Select categories to focus on specific areas of health</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {categories.map((category) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={category}
                  checked={selectedCategories.includes(category)}
                  onCheckedChange={() => toggleCategory(category)}
                />
                <Label htmlFor={category}>{category}</Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {filteredTips.map((tip) => (
          <Card key={tip.id} className={completedTips.includes(tip.id) ? "bg-green-50" : ""}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                {tip.title}
                <Checkbox
                  checked={completedTips.includes(tip.id)}
                  onCheckedChange={() => toggleTipCompletion(tip.id)}
                />
              </CardTitle>
              <CardDescription>{tip.category}</CardDescription>
            </CardHeader>
            <CardContent>
              <p>{tip.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
          <CardDescription>Track your health tip completions</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-lg font-semibold">
            {completedTips.length} out of {healthTips.length} tips completed
          </p>
          <progress className="w-full mt-2" value={completedTips.length} max={healthTips.length}></progress>
        </CardContent>
      </Card>
    </div>
  )
}
