"use client"

import { useState } from "react"
import Link from "next/link"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Activity, Brain } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

const mockHealthData = [
  { date: "2025-01", weight: 70, bmi: 24.5, bloodPressure: 120, stressLevel: 60, attentionScore: 75 },
  { date: "2025-02", weight: 69, bmi: 24.2, bloodPressure: 118, stressLevel: 55, attentionScore: 78 },
  { date: "2025-03", weight: 68, bmi: 23.9, bloodPressure: 117, stressLevel: 50, attentionScore: 80 },
  { date: "2025-04", weight: 67.5, bmi: 23.7, bloodPressure: 116, stressLevel: 45, attentionScore: 82 },
  { date: "2025-05", weight: 67, bmi: 23.5, bloodPressure: 115, stressLevel: 40, attentionScore: 85 },
]

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Your Health Dashboard</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="metrics">Health Metrics</TabsTrigger>
          <TabsTrigger value="mental">Mental Wellness</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Health Score</CardTitle>
                <CardDescription>Your overall health rating</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <Progress value={75} className="w-2/3" />
                  <span className="text-2xl font-bold">75/100</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Factors</CardTitle>
                <CardDescription>Areas that need attention</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5">
                  <li>High stress levels</li>
                  <li>Insufficient sleep</li>
                  <li>Low physical activity</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="metrics">
          <Card>
            <CardHeader>
              <CardTitle>Health Metrics Over Time</CardTitle>
              <CardDescription>Track your progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={mockHealthData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Line yAxisId="left" type="monotone" dataKey="weight" stroke="#8884d8" />
                    <Line yAxisId="left" type="monotone" dataKey="bmi" stroke="#82ca9d" />
                    <Line yAxisId="right" type="monotone" dataKey="bloodPressure" stroke="#ffc658" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="mental">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Stress Levels</CardTitle>
                <CardDescription>Based on your latest assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={40} className="w-full" />
                  <p className="text-sm text-muted-foreground">Your stress level: 40/100 (Moderate)</p>
                  <Button asChild>
                    <Link href="/stress-analysis">
                      <Activity className="mr-2 h-4 w-4" /> Take Stress Analysis
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Attention Span</CardTitle>
                <CardDescription>Your latest test results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={85} className="w-full" />
                  <p className="text-sm text-muted-foreground">Your attention score: 85/100 (Excellent)</p>
                  <Button asChild>
                    <Link href="/attention-test">
                      <Brain className="mr-2 h-4 w-4" /> Take Attention Test
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="goals">
          <Card>
            <CardHeader>
              <CardTitle>Health Goals</CardTitle>
              <CardDescription>Your personalized targets</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <li>
                  <div className="flex justify-between items-center mb-1">
                    <span>Reduce weight to 65kg</span>
                    <span>70%</span>
                  </div>
                  <Progress value={70} />
                </li>
                <li>
                  <div className="flex justify-between items-center mb-1">
                    <span>30 minutes of exercise daily</span>
                    <span>50%</span>
                  </div>
                  <Progress value={50} />
                </li>
                <li>
                  <div className="flex justify-between items-center mb-1">
                    <span>Improve sleep quality</span>
                    <span>60%</span>
                  </div>
                  <Progress value={60} />
                </li>
                <li>
                  <div className="flex justify-between items-center mb-1">
                    <span>Reduce stress levels</span>
                    <span>40%</span>
                  </div>
                  <Progress value={40} />
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
