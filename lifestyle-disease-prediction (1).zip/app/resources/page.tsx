import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const articles = [
  {
    title: "Understanding Cardiovascular Health",
    description: "Learn about heart disease prevention and management.",
    category: "Heart Health",
  },
  {
    title: "Nutrition Basics for a Healthy Lifestyle",
    description: "Discover the fundamentals of a balanced diet.",
    category: "Nutrition",
  },
  {
    title: "Stress Management Techniques",
    description: "Effective ways to reduce stress in your daily life.",
    category: "Mental Health",
  },
]

const expertSessions = [
  { expert: "Dr. Emily Chen", topic: "Diabetes Prevention", date: "June 15, 2025", time: "2:00 PM EST" },
  {
    expert: "Nutritionist Mark Johnson",
    topic: "Meal Planning for Weight Loss",
    date: "June 18, 2025",
    time: "1:00 PM EST",
  },
  {
    expert: "Fitness Coach Sarah Brown",
    topic: "Home Workouts for Beginners",
    date: "June 20, 2025",
    time: "11:00 AM EST",
  },
]

export default function Resources() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Health Resources</h1>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Featured Articles</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {articles.map((article) => (
            <Card key={article.title}>
              <CardHeader>
                <CardTitle>{article.title}</CardTitle>
                <CardDescription>{article.category}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{article.description}</p>
                <Button>Read More</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Upcoming Expert Sessions</h2>
        <div className="space-y-4">
          {expertSessions.map((session) => (
            <Card key={session.topic}>
              <CardHeader>
                <CardTitle>{session.topic}</CardTitle>
                <CardDescription>with {session.expert}</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Date: {session.date}</p>
                <p>Time: {session.time}</p>
                <Button className="mt-4">Register</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
