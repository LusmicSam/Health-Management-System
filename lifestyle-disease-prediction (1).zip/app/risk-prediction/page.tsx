"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

export default function RiskPrediction() {
  const [formData, setFormData] = useState({
    age: 30,
    gender: "male",
    bmi: 25,
    bloodPressure: 120,
    cholesterol: 200,
    glucose: 100,
    smoking: "no",
    alcohol: "no",
    physicalActivity: 3,
  })
  const [prediction, setPrediction] = useState<string | null>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSliderChange = (name: string, value: number[]) => {
    setFormData((prev) => ({ ...prev, [name]: value[0] }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would be an API call to your ML model
    const response = await fetch("/api/predict-risk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })
    const data = await response.json()
    setPrediction(data.prediction)
  }

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Disease Risk Prediction</h1>
      <Card>
        <CardHeader>
          <CardTitle>Health Information</CardTitle>
          <CardDescription>Enter your health details for risk assessment</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input id="age" name="age" type="number" value={formData.age} onChange={handleInputChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select name="gender" onValueChange={(value) => handleSelectChange("gender", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bmi">BMI</Label>
                <Input id="bmi" name="bmi" type="number" value={formData.bmi} onChange={handleInputChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bloodPressure">Blood Pressure (Systolic)</Label>
                <Input
                  id="bloodPressure"
                  name="bloodPressure"
                  type="number"
                  value={formData.bloodPressure}
                  onChange={handleInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cholesterol">Cholesterol (mg/dL)</Label>
                <Input
                  id="cholesterol"
                  name="cholesterol"
                  type="number"
                  value={formData.cholesterol}
                  onChange={handleInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="glucose">Glucose (mg/dL)</Label>
                <Input
                  id="glucose"
                  name="glucose"
                  type="number"
                  value={formData.glucose}
                  onChange={handleInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smoking">Smoking</Label>
                <Select name="smoking" onValueChange={(value) => handleSelectChange("smoking", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Smoking status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no">No</SelectItem>
                    <SelectItem value="yes">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="alcohol">Alcohol Consumption</Label>
                <Select name="alcohol" onValueChange={(value) => handleSelectChange("alcohol", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Alcohol consumption" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no">No</SelectItem>
                    <SelectItem value="yes">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="physicalActivity">Physical Activity (hours/week)</Label>
              <Slider
                id="physicalActivity"
                min={0}
                max={10}
                step={0.5}
                value={[formData.physicalActivity]}
                onValueChange={(value) => handleSliderChange("physicalActivity", value)}
              />
              <p className="text-sm text-muted-foreground">{formData.physicalActivity} hours/week</p>
            </div>
            <Button type="submit">Predict Risk</Button>
          </form>
        </CardContent>
      </Card>

      {prediction && (
        <Card>
          <CardHeader>
            <CardTitle>Risk Prediction Result</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-semibold">{prediction}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
